package com.tech_domain.nemo_magdy.aflamy;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Rect;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.tech_domain.nemo_magdy.aflamy.related_data.MovieData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nemo_Magdy on 9/3/2016.
 */

public class MainActivityFragment extends Fragment {

    private RecyclerView recyclerView;
    private AlbumsAdapter adapter;
    private List<MovieData> albumList;
    private ProgressDialog loading;
    private MainActivity mainActivity;
    private SharedPreferences sharedPreferences;
    public MainActivityFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.main_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.action_sorting){
            showRadioButtonDialog();

            return true;
        }
        if(id == R.id.action_fav) {
            startActivity(new Intent(getActivity(),Favorite.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        albumList = new ArrayList<>();
        adapter = new AlbumsAdapter(getActivity(), albumList);
        mainActivity = new MainActivity();
        sharedPreferences = getActivity().getSharedPreferences("myData",Context.MODE_PRIVATE);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(10), true));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        return view;
    }

    public void updateMovies() {
        FetchMovieData newTask = new FetchMovieData();
        newTask.execute("");
    }

    @Override
    public void onStart() {
        super.onStart();
        updateMovies();
    }

    private void showRadioButtonDialog() {
        // custom dialog
        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.radio_button_dialog);
        final RadioGroup rg = (RadioGroup) dialog.findViewById(R.id.radio_group);

        RadioButton rate_Radio_Button = (RadioButton) dialog.findViewById(R.id.rate_RB);
        RadioButton pop_Radio_Button = (RadioButton) dialog.findViewById(R.id.pop_RB);
        Button okbButton = (Button) dialog.findViewById(R.id.ok_button);
        if(sharedPreferences.getBoolean("is_Pop",false))
            pop_Radio_Button.setChecked(true);
        else
            rate_Radio_Button.setChecked(true);

        okbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor =sharedPreferences.edit();
                int selectedID = rg.getCheckedRadioButtonId();
                if(selectedID == R.id.pop_RB)
                    editor.putBoolean("is_Pop",true);
                else
                    editor.putBoolean("is_Pop",false);

                String sortBy="";
                boolean sortpop = sharedPreferences.getBoolean("is_Pop",false);
                if(sortpop)
                    sortBy="rate.desc";
                else
                    sortBy="popularity.desc";

                editor.putString("sort_by",sortBy);

                editor.commit();
                dialog.dismiss();
                updateMovies();
            }
        });
        dialog.show();

    }

    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view); // item position
            int column = position % spanCount; // item column

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount; // spacing - column * ((1f / spanCount) * spacing)
                outRect.right = (column + 1) * spacing / spanCount; // (column + 1) * ((1f / spanCount) * spacing)

                if (position < spanCount) { // top edge
                    outRect.top = spacing;
                }
                outRect.bottom = spacing; // item bottom
            } else {
                outRect.left = column * spacing / spanCount; // column * ((1f / spanCount) * spacing)
                outRect.right = spacing - (column + 1) * spacing / spanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
                if (position >= spanCount) {
                    outRect.top = spacing; // item top
                }
            }
        }
    }

    /**
     * Converting dp to pixel
     */
    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }


    public class FetchMovieData extends AsyncTask<String, Void, List<MovieData>> {

        private final String LOG_TAG = FetchMovieData.class.getSimpleName();

        @Override
        protected void onPreExecute() {
            try {
                loading = ProgressDialog.show(getActivity(), "Aflamy", "Please wait...", true, true);
            } catch (Exception e) {

            }

            super.onPreExecute();
        }

        private List<MovieData> getMovieDataFromJson(String movieDBJsonStr) throws JSONException {

            // These are the names of the JSON objects that need to be extracted.
            final String MDB_RESULT = "results";
            final String MDB_POSTER_PATH = "poster_path";
            final String MDB_OVERVIEW = "overview";
            final String MDB_TITLE = "title";
            final String MDB_DATE = "release_date";
            final String MDB_RATE = "vote_count";
            final String MDB_ID = "id";

            JSONObject movieJson = new JSONObject(movieDBJsonStr);
            JSONArray aflamArray = movieJson.getJSONArray(MDB_RESULT);
            List<MovieData> cinemaList = new ArrayList<>();
            for (int i = 0; i < aflamArray.length(); i++) {

                String poster_path;
                String overview;
                String title;
                String date;
                String movID;
                double rate;

                JSONObject singleMovie = aflamArray.getJSONObject(i);

                poster_path = singleMovie.getString(MDB_POSTER_PATH);
                overview = singleMovie.getString(MDB_OVERVIEW);
                title = singleMovie.getString(MDB_TITLE);
                date = singleMovie.getString(MDB_DATE);
                rate = Double.parseDouble(singleMovie.getString(MDB_RATE));
                movID = singleMovie.getString(MDB_ID);
                cinemaList.add(new MovieData(movID, title, overview, poster_path, date, rate));


            }
            return cinemaList;

        }

        @Override
        protected List<MovieData> doInBackground(String... params) {

            if (params.length == 0) {
                return null;
            }

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String sortBy = sharedPreferences.getString("sort_by","rate.desc");
            String movieDBJsonStr = null;

            try {
                URL url = new URL("http://api.themoviedb.org/3/discover/movie?sort_by="+sortBy+"&api_key=1962bc00de1584940b4f338dc55d6887");
//                URL url = new URL("http://api.themoviedb.org/3/discover/movie?sorrt_by="+params[0]+"&api_key=1962bc00de1584940b4f338dc55d6887");
                Log.i("URL",url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }
                movieDBJsonStr = buffer.toString();
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);

                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }

            try {
                return getMovieDataFromJson(movieDBJsonStr);
            } catch (JSONException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
                e.printStackTrace();
            }


            return null;
        }

        protected void onPostExecute(List<MovieData> albumList) {
            adapter = new AlbumsAdapter(getActivity(), albumList);
            recyclerView.setAdapter(adapter);
            loading.dismiss();

        }

    }

    public class AlbumsAdapter extends RecyclerView.Adapter<AlbumsAdapter.MyViewHolder> {

        private Context myContext;
        private List<MovieData> albumList;


        public class MyViewHolder extends RecyclerView.ViewHolder {
            public TextView title;
            public ImageView thumbnail, overflow;

            public MyViewHolder(View view) {
                super(view);
                title = (TextView) view.findViewById(R.id.title);
                thumbnail = (ImageView) view.findViewById(R.id.thumbnail);
                overflow = (ImageView) view.findViewById(R.id.overflow);
            }
        }

        public AlbumsAdapter(Context myContext, List<MovieData> albumList) {
            this.myContext = myContext;
            this.albumList = albumList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, int position) {
            final MovieData film = albumList.get(position);
            holder.title.setText(film.getTitle());

            Picasso.with(myContext).load("http://image.tmdb.org/t/p/w185/" + film.getPosterLink()).into(holder.thumbnail);

            holder.thumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    ((MainActivity) myContext).inMethod(film);
                }
            });
            holder.overflow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showPopupMenu(holder.overflow);
                }
            });
        }

        private void showPopupMenu(View view) {
            PopupMenu popup = new PopupMenu(myContext, view);
            MenuInflater inflater = popup.getMenuInflater();
            inflater.inflate(R.menu.menu_album, popup.getMenu());
            popup.setOnMenuItemClickListener(new MyMenuItemClickListener());
            popup.show();
        }

        class MyMenuItemClickListener implements PopupMenu.OnMenuItemClickListener {

            public MyMenuItemClickListener() {
            }

            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_add_favourite:
                        Toast.makeText(myContext, "Add to favourite", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_play_next:
                        Toast.makeText(myContext, "Play next", Toast.LENGTH_SHORT).show();
                        return true;
                    default:
                }
                return false;
            }
        }

        @Override
        public int getItemCount() {
            return albumList.size();
        }
    }

    public interface myInterface {

        void inMethod(MovieData film);
    }
}