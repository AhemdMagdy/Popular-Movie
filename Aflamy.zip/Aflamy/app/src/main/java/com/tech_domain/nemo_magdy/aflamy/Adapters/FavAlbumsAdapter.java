package com.tech_domain.nemo_magdy.aflamy.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tech_domain.nemo_magdy.aflamy.DetailsActivity;
import com.tech_domain.nemo_magdy.aflamy.Favorite;
import com.tech_domain.nemo_magdy.aflamy.MainActivity;
import com.tech_domain.nemo_magdy.aflamy.R;
import com.tech_domain.nemo_magdy.aflamy.related_data.MovieData;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * Created by Nemo_Magdy on 9/3/2016.
 */
public class FavAlbumsAdapter extends RecyclerView.Adapter<FavAlbumsAdapter.MyViewHolder> {

    private Context myContext;
    private List<MovieData> albumList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public ImageView thumbnail, overflow;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.title);
            thumbnail = (ImageView) view.findViewById(R.id.thumbnail);
            overflow = (ImageView) view.findViewById(R.id.overflow);
        }
    }

    public FavAlbumsAdapter(Context myContext, List<MovieData> albumList) {
        this.myContext = myContext;
        this.albumList = albumList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        final MovieData favorite = albumList.get(position);
        holder.title.setText(favorite.getTitle());
        holder.thumbnail.setImageBitmap(favorite.getPoster());

        holder.thumbnail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((Favorite) myContext).inMethod(favorite);
            }
        });
        holder.overflow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupMenu(holder.overflow);
            }
        });
    }
    public static byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(myContext, view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.fav_menu_album, popup.getMenu());
        popup.setOnMenuItemClickListener(new MyMenuItemClickListener());
        popup.show();
    }

    class MyMenuItemClickListener implements PopupMenu.OnMenuItemClickListener {

        public MyMenuItemClickListener() {
        }

        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.action_add_favourite:
                    Toast.makeText(myContext, "Removed Favourite", Toast.LENGTH_SHORT).show();
                    return true;
                case R.id.action_play_next:
                    Toast.makeText(myContext, "Play next", Toast.LENGTH_SHORT).show();
                    return true;
                default:
            }
            return false;
        }
    }

    @Override
    public int getItemCount() {
        return albumList.size();
    }
}
