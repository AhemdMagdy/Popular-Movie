package com.tech_domain.nemo_magdy.aflamy;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

/**
 * Created by Nemo_Magdy on 7/29/2016.
 */
public class SplashScreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        Thread background = new Thread() {
            public void run() {

                try {
                    // Thread will sleep for 1 second
                    sleep(2*1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {

                    SplashScreen.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(isOnLine()){
                                Intent i=new Intent(getBaseContext(),MainActivity.class);
                                startActivity(i);
                            }else{
                                Toast.makeText(getBaseContext(), "Please Check Your Connection!!\n and Try again Later...", Toast.LENGTH_LONG).show();
//                                Intent i = new Intent(getBaseContext() , Favotite_Activity.class);
//                                startActivity(i);
                                Intent i=new Intent(getBaseContext(),Favorite.class);
                                startActivity(i);

                            }
                        }
                    });
                }
            }
        };

        // start thread
        background.start();

}
    public  Boolean  isOnLine(){
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
