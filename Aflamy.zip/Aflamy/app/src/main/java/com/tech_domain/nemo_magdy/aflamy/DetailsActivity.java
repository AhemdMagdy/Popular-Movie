package com.tech_domain.nemo_magdy.aflamy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.tech_domain.nemo_magdy.aflamy.related_data.MovieData;

/**
 * Created by Nemo_Magdy on 9/3/2016.
 */
public class DetailsActivity extends ActionBarActivity {

    FragmentManager fragmentManager;
   Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

     MovieData film = getIntent().getExtras().getParcelable("mybundle");

//        String title = intent.getExtras().getString("title");
//        double   rate = intent.getExtras().getDouble("rate");
//        String  date = intent.getExtras().getString("date");
//        String   overview = intent.getExtras().getString("overview");
//        String   posterPath = intent.getExtras().getString("poster_path");
//        String   movId = intent.getExtras().getString("id");
//        byte[]   posterImage = intent.getExtras().getByteArray("poster");
//        String   reviews = intent.getExtras().getString("Reviews");
//        String   trailer = intent.getExtras().getString("trial");
//        String  trailersKey = intent.getExtras().getString("trial_key");
//
        DetailsFragment detailsFragment = DetailsFragment.getInstanceFrag(film);
        getSupportFragmentManager().beginTransaction().replace(R.id.fram_detail,detailsFragment).commit();
    }
}

