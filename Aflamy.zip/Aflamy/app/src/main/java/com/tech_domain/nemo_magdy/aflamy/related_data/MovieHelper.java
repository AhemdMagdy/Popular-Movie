package com.tech_domain.nemo_magdy.aflamy.related_data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.test.mock.MockContentProvider;

/**
 * Created by Nemo_Magdy on 9/15/2016.
 */
public class MovieHelper extends SQLiteOpenHelper {
    public MovieHelper(Context context){
        super(context, MovieSchema.DB_NAME, null, MovieSchema.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table "+MovieSchema.TABLE_NAME+" ( "+MovieSchema.COL_ID+" integer primary key autoincrement not null , "+
                MovieSchema.COL_MOVIE_ID+" integer not null , "+
                MovieSchema.COL_RATE+" real not null , "+
                MovieSchema.COL_DATE+" text not null , "+
                MovieSchema.COL_TITLE+" text not null , "+
                MovieSchema.COL_OVERVIEW+" text not null , "+
                MovieSchema.COL_REVIEWS+" text not null , "+
                MovieSchema.COL_TRAILERS+" text not null , "+
                MovieSchema.COL_TRAILERS_KEY+" text not null ,"+
                MovieSchema.COL_POSTER+" blob not null ) ";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
