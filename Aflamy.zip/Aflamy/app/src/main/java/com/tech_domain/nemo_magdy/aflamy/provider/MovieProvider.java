package com.tech_domain.nemo_magdy.aflamy.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.Nullable;

import com.tech_domain.nemo_magdy.aflamy.related_data.MovieHelper;
import com.tech_domain.nemo_magdy.aflamy.related_data.MovieSchema;

/**
 * Created by Nemo_Magdy on 9/15/2016.
 */
public class MovieProvider extends ContentProvider {
    private static final String author_Nemo = "com.tech_domain.nemo_magdy.aflamy.MovieProvider";
    private static final int CHOICE_TABLE = 1;
    private UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    MovieHelper myHelper ;
    SQLiteDatabase db ;

    @Override
    public boolean onCreate() {
        uriMatcher.addURI(author_Nemo , MovieSchema.TABLE_NAME , CHOICE_TABLE );
        return false;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] strings, String s, String[] strings1, String s1) {
        myHelper = new MovieHelper(getContext());
        db = myHelper.getReadableDatabase();
        int result =  uriMatcher.match(uri);
        if(result == CHOICE_TABLE){
            return   db.query(MovieSchema.TABLE_NAME  , strings , s ,strings1 , null , null,s1 );
        }


        return null;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(Uri uri, String s, String[] strings) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues contentValues, String s, String[] strings) {
        return 0;
    }
}
