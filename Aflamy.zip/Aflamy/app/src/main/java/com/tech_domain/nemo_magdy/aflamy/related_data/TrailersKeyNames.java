package com.tech_domain.nemo_magdy.aflamy.related_data;

import java.util.ArrayList;

/**
 * Created by Nemo_Magdy on 9/16/2016.
 */
public class TrailersKeyNames {
    private ArrayList<String> trailKey;
    private ArrayList<String> trailName;

    public TrailersKeyNames(ArrayList<String> trailKey, ArrayList<String> trailName){
        this.setTrailKey(trailKey);
        this.setTrailName(trailName);
    }

    public void setTrailName(ArrayList<String> trailName) { this.trailName = trailName; }
    public void setTrailKey(ArrayList<String> trailKey) { this.trailKey = trailKey; }
    public ArrayList<String> getTrailName() { return trailName; }
    public ArrayList<String> getTrailKey() { return trailKey; }
}
