package com.tech_domain.nemo_magdy.aflamy;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.tech_domain.nemo_magdy.aflamy.related_data.MovieData;

public class Favorite extends AppCompatActivity implements MainActivityFragment.myInterface {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    }

    @Override
    public void inMethod(MovieData film) {
        Intent intent = new Intent(Favorite.this, DetailsActivity.class);
        intent.putExtra("mybundle",film);
        startActivity(intent);
    }
}
